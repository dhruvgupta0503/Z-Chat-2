export const orange="#ea7070";
export const grayColor="rgba(247,247,247,1)";
export const lightBlue="#2694ab"
export const matblack="#1c1c1c"
export const bgGradient="linear-gradient(rgba(200,200,200,0.5),rgba(120,110,220,0.5))";
export const purple="rgba(75,12,192,2)"
export const purpleLight="rgba(75,12,192,0.2)"