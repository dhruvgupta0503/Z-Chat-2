// import React from 'react'

function NotFound() {
  return (
    <div>NotFound hlo</div>
  )
}

export default NotFound